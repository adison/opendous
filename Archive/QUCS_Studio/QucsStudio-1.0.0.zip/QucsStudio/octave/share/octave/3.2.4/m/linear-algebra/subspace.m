## Copyright (C) 2008, 2009 VZLU Prague, a.s., Czech Republic
##
## This file is part of Octave.
##
## Octave is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or (at
## your option) any later version.
##
## Octave is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with Octave; see the file COPYING.  If not, see
## <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {Function File} {@var{angle} =} subspace (@var{a}, @var{B})
## Determine the largest principal angle between two subspaces
## spanned by columns of matrices @var{a} and @var{b}.
## @end deftypefn

## Author: Jaroslav Hajek <highegg@gmail.com>

## reference:
## [1]  Andrew V. Knyazev, Merico E. Argentati:
##   Principal Angles between Subspaces in an A-Based Scalar Product: 
##  Algorithms and Perturbation Estimates.  
##  SIAM Journal on Scientific Computing, Vol. 23 no. 6, pp. 2008-2040
##
## other texts are also around...

function ang = subspace (a, b)

  if (nargin != 2)
    print_usage ();
  elseif (ndims (a) != 2 || ndims (b) != 2)
    error ("subspace: expecting A and B to be 2-dimensional arrays");
  elseif (rows (a) != rows (b))
    error ("subspace: column dimensions of a and b must match");
  endif

  a = orth (a);
  b = orth (b);
  c = a'*b;
  scos = min (svd (c));
  if (scos^2 > 1/2)
    if (columns (a) >= columns (b))
      c = b - a*c;
    else
      c = a - b*c';
    endif
    ssin = max (svd (c));
    ang = asin (min (ssin, 1));
  else
    ang = acos (scos);
  endif

endfunction
