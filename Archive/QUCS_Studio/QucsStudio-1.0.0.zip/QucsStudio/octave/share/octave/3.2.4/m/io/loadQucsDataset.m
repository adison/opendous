% Load all variables from a Qucs dataset file.
% The filename must be in the variable 'qucsFilename'.
% The created variables have the same name as in the file.

% script written with Octave 3.2.4
% Copyright 2010 by Michael Margraf (michael.margraf@alumni.tu-berlin.de)
% Published under GNU General Public License (GPL V2). No warranty at all.

_fid = fopen(qucsFilename, "rb");
if _fid < 0
    error("Cannot open data file.")
    return
endif

if strcmp(fscanf(_fid, "%8s", "C"), "QucsData") == 0
    error("File is not a Qucs data file.")
    fclose(_fid);
    return
endif

_version = fread(_fid, 1, "int32", 0, "ieee-le");
_size = fread(_fid, 1, "int32", 0, "ieee-le");

% load header containing a list of all variables in the file
_header = fread(_fid, _size, "uchar");

_pos = 0;
_type = 0;
_count = 0;
_index = 0;
% search for the variable
while _index+9 <= _size
    _pos = _pos + _count;
    _type  = _header(_index+1) + 256*(_header(_index+2) + 256*(_header(_index+3) + 256*_header(_index+4)));
    _count = _header(_index+5) + 256*(_header(_index+6) + 256*(_header(_index+7) + 256*_header(_index+8)));

    _name = "";
    _dependency = "";
    _index = _index + 9;
    while _header(_index) > 0
        _name = [_name char(_header(_index))];
        _index = _index + 1;
    end
    if bitget(_type, 2) == 1  % is dependent variable?
        _index = _index + 1;
        while _header(_index) > 0
            _dependency = [_dependency char(_header(_index))];
            _index = _index + 1;
        end
    end

    if bitget(_type, 3) == 0  % complex-valued numbers?
        _count = 2*_count;
        _data = fread(_fid, _count, "double", 0, "ieee-le");
        _data = _data(1:2:_count-1) + j*_data(2:2:_count);
    else
        _data = fread(_fid, _count, "double", 0, "ieee-le");
    end

    eval(strcat(_name, "=_data;"));
end

fclose(_fid);

clear _fid;
clear _version;
clear _size;
clear _header;
clear _pos;
clear _type;
clear _count;
clear _index;
clear _name;
clear _data;
clear _dependency;
